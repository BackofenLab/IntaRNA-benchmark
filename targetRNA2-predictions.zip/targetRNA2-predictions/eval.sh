

###########  recovery and time evaluation  ##############################

# get target recovery results
( # start output file
# top-x thresholds for which to print recovery information
threshold="10 50 100"
printf "test";
for t in $threshold; do
  printf "\ttop-$t";
done
echo
for f in */benchmark.csv; do 
    printf "$f\t"; 
    for m in $threshold; do 
        awk -F ';' -v m=$m '{if ($4<=m){print $0;}}' $f | wc -l | tr "\n" "\t"; 
    done; 
    echo; 
done | sed -e "s/\/benchmark.csv//g"
) > benchmark-results.tsv # output file

# get runtime results
#cat */runTime.csv | tr ";" "\t" | sort | uniq > benchmark-runtime.tsv

#awk 'BEGIN{l="ajshd";s=0;}{if (NR==1){print $1";time";} else{for(i=4; i<=NF;i++){s=s+$i;}; if($1==l){print $1";"s; s=0;}; l=$1;}}' benchmark-runtime.tsv | tr ";" "\t" > benchmark-runtime-sum.tsv

